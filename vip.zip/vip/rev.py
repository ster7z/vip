from requests import get
from re import findall
from multiprocessing.dummy import Pool



def rev(ip) :
    try :
        url = 'https://api.reverseip.my.id/?ip='+ip
        send_data = get(url, timeout=10).text
        attack  = findall('"(.*?)"',send_data)[3:]
        for domain in attack :
            print(domain)
            open('sites_rev.txt','a').write('http://'+domain+'\n')
    except :
        pass
def main () :
    ad = input('Enter list ip : ')
    opens = open(ad, mode='r', errors='ignore').read().splitlines()
    utchiha = Pool(int(100))
    utchiha.map(rev, opens)
   

main()
